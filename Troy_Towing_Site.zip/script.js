
function submitForm(e){
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  const body = `New quote request:\n
Name: ${data.name}
Phone: ${data.phone}
Pickup: ${data.pickup}
Dropoff: ${data.dropoff || "-"}
Vehicle: ${data.vehicle}
Service: ${data.service}
Details: ${data.details || "-"}`;

  const mailto = `mailto:info@troytowingllc.com?subject=Quote%20Request&body=${encodeURIComponent(body)}`;
  window.location.href = mailto;
  alert('Thanks! We opened your email app so you can send us the details.');
  return false;
}
document.getElementById('year').textContent = new Date().getFullYear();
